<?php $__env->startSection('content'); ?>
<h1>Contact</h1>
<?php if(count($people)): ?>
    <ul>
    <?php $__currentLoopData = $people; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($person); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>
    

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
<h1 >This is the footer section</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_first_laravel_project\resources\views/contact.blade.php ENDPATH**/ ?>