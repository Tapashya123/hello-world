<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<div class="container">
	<?php echo $__env->yieldContent('content'); ?>
</div>
	<?php echo $__env->yieldContent('footer'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\my_first_laravel_project\resources\views/layouts/app.blade.php ENDPATH**/ ?>