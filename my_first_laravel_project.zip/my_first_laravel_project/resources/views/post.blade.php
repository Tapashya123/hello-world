@extends('layouts.app')

@section('content')
<h1>Posts</h1>
@stop